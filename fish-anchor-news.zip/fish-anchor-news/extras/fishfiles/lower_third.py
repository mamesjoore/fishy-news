#!/usr/bin/env python3
"""Local news lower-third artwork; no external assets or services."""
import argparse
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

SIZE = (1080, 1920)

def font(family, size, bold=False):
    path = subprocess.check_output(['fc-match', family, '-f', '%{file}'], text=True).strip()
    if not path or not Path(path).is_file():
        raise RuntimeError(f'Installed font missing: {family}')
    f = ImageFont.truetype(path, size)
    if bold and hasattr(f, 'set_variation_by_name'):
        try:
            f.set_variation_by_name('Bold')
        except (ValueError, OSError):
            pass
    return f

def wrap(text, f, width):
    lines = []
    for word in text.split():
        if lines and f.getlength(lines[-1] + ' ' + word) <= width:
            lines[-1] += ' ' + word
        else:
            lines.append(word)
    return lines

def make_overlay(title, part, output):
    im = Image.new('RGBA', SIZE)
    d = ImageDraw.Draw(im)
    d.rectangle((0, 1520, 1079, 1919), fill=(9, 17, 24, 255))
    d.rectangle((48, 1520, 1032, 1526), fill=(239, 120, 36, 255))
    tag = font('Bebas Neue', 70)
    d.text((48, 1544), 'FISH FILES', font=tag, fill='white')
    p = f'PART {part}'
    d.text((1032-tag.getlength(p), 1544), p, font=tag, fill='white')
    for size in range(62, 35, -2):
        main = font('Montserrat', size, True)
        lines = wrap(title, main, 984)
        if len(lines) <= 2 and all(main.getlength(s) <= 984 for s in lines):
            break
    else:
        raise ValueError('Episode title does not fit lower third')
    for i, line in enumerate(lines):
        d.text((48, 1640+i*78), line, font=main, fill='white')
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    im.save(output)
    return im

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--title', required=True)
    p.add_argument('--part', required=True, type=int)
    p.add_argument('--out', required=True)
    a = p.parse_args()
    make_overlay(a.title, a.part, a.out)
