#!/usr/bin/env python3
"""Render a supplied, timed FISH FILES episode entirely offline."""
import argparse
import bisect
import json
import math
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf
from PIL import Image, ImageDraw, ImageOps
from lower_third import SIZE, font, make_overlay, wrap

FPS, SR = 30, 48000
BUILD = Path(__file__).resolve().parent
ROOT = BUILD.parent


def mouth_states(vo, words, nf):
    """Self-contained fn16/fn17 RMS algorithm, with silence/empty guards."""
    hop = SR // FPS
    vo = np.pad(vo, (0, max(0, nf*hop-len(vo))))
    env = np.array([np.sqrt(np.mean(vo[i*hop:(i+1)*hop]**2)+1e-12)
                    for i in range(nf)])
    envdb = 20*np.log10(env+1e-9)
    active = envdb[envdb > -60]
    gmax = np.percentile(active, 95) if active.size else 0.0
    win = [(w['s'], w['e']) for w in words]
    st = np.zeros(nf, int)
    for i in range(nf):
        tt = (i+0.5)/FPS
        if not any(a-0.02 <= tt <= b+0.02 for a, b in win):
            continue
        lm = envdb[max(0, i-5):i+6].max()
        e = envdb[i]
        st[i] = 0 if e < gmax-30 else (2 if (e > lm-5 and e > gmax-17)
                                      else (1 if e > gmax-24 else 0))
    i = 0
    while i < nf:
        j = i
        while j < nf and st[j] == st[i]:
            j += 1
        if j-i < 2 and i > 0:
            st[i:j] = st[i-1]
        i = j
    # Run merging must never open a silent gap or the final hold.
    last = max(w['e'] for w in words)
    for i in range(nf):
        tt = (i+0.5)/FPS
        if tt > last+0.05 or not any(a-0.02 <= tt <= b+0.02 for a, b in win):
            st[i] = 0
    return st


def chunks(words):
    """Partition each sentence into 2–4 words, keeping all source tokens intact."""
    result = []
    for sent in sorted({w['sent'] for w in words}):
        pending = [w for w in words if w['sent'] == sent]
        while pending:
            n = min(4, len(pending))
            for k in range(2, n+1):
                if re.search(r'[.!?,;:]$', pending[k-1]['w']) and len(pending)-k != 1:
                    n = k
                    break
            if len(pending)-n == 1 and n > 2:
                n -= 1
            group, pending = pending[:n], pending[n:]
            text = ' '.join(w['w'] for w in group).replace('O Block', 'O-Block')
            result.append((group[0]['s'], group[-1]['e'], text))
    return sorted(result)


def text_patch(text, credit=False):
    # Credits occupy a reserved strip directly above the lower third.
    size = 28 if credit else 72
    width = 984 if credit else 960
    while True:
        f = font('Montserrat', size, True)
        lines = wrap(text, f, width)
        if all(f.getlength(s) <= width for s in lines) and len(lines) <= (2 if credit else 3):
            break
        size -= 2
        if size < (22 if credit else 44):
            raise ValueError(f'Text cannot fit safely: {text!r}')
    height = len(lines)*(size+14)+24
    im = Image.new('RGBA', (1080, height))
    d = ImageDraw.Draw(im)
    if credit:
        d.rectangle((32, 0, 1048, height), fill=(0, 0, 0, 180))
    for i, line in enumerate(lines):
        x = 48 if credit else (1080-f.getlength(line))/2
        d.text((x, 6+i*(size+14)), line, font=f, fill='white',
               stroke_width=2 if credit else 4, stroke_fill='black')
    return im


def photo_frame(source, index, progress, map_photo=False):
    w, h = source.size
    base_w = min(w, h*1080/1920)
    base_h = base_w*1920/1080
    u = progress*progress*(3-2*progress)
    zoom = 1 + (0.04+0.01*(index % 5))*(u if index % 2 == 0 else 1-u)
    cw, ch = base_w/zoom, base_h/zoom
    # Alternate horizontal pan direction; tall map stays at its header.
    fx = 0.35+0.30*(u if index % 2 else 1-u)
    fy = 0.0 if map_photo else 0.44+0.12*(u if index % 3 else 1-u)
    x, y = (w-cw)*fx, (h-ch)*fy
    return source.transform(SIZE, Image.Transform.EXTENT,
                            (x, y, x+cw, y+ch), Image.Resampling.BICUBIC)


def load_inputs(a):
    for p in (a.wav, a.meta, a.shots):
        if not p.is_file():
            raise FileNotFoundError(f'Required input missing: {p}')
    meta = json.loads(a.meta.read_text())
    plan = json.loads(a.shots.read_text())
    sentences = meta.get('sentences', meta.get('items'))
    words = meta['words']
    if not sentences or not words or not plan['shots']:
        raise ValueError('Empty sentences, words, or shot plan')
    if plan['id'] != a.ep:
        raise ValueError('Episode ID does not match shot plan')
    for i, s in enumerate(sentences):
        if not 0 <= s['start'] < s['end'] or (i and s['start'] < sentences[i-1]['end']):
            raise ValueError(f'Invalid/overlapping sentence: {s}')
    for i, w in enumerate(words):
        if (not isinstance(w['sent'], int) or not 0 <= w['sent'] < len(sentences)
                or not 0 <= w['s'] < w['e'] or not str(w['w']).strip()
                or (i and w['s'] < words[i-1]['s'])):
            raise ValueError(f'Invalid word: {w}')
        s = sentences[w['sent']]
        if w['s'] < s['start']-0.05 or w['e'] > s['end']+0.05:
            raise ValueError(f'Word outside sentence timing: {w}')
    if max(w['e'] for w in words) > sentences[-1]['end']:
        raise ValueError('Last word extends past last sentence')
    ids = {s['id']: i for i, s in enumerate(sentences)}
    shots = plan['shots']
    next_index = 0
    photos = {}
    for sh in shots:
        lo, hi = ids[sh['start']], ids[sh['end']]
        if lo != next_index or hi < lo:
            raise ValueError('Shots must cover every sentence exactly once, in order')
        next_index = hi+1
        if sh['kind'] == 'photo':
            p = (a.photos / sh['file']).resolve()
            if not p.is_relative_to(a.photos.resolve()) or not p.is_file():
                raise FileNotFoundError(f'Photo missing or outside photos directory: {p}')
            if not sh['credit']:
                raise ValueError(f'Photo credit missing: {p}')
            with Image.open(p) as im:
                photos[sh['file']] = ImageOps.exif_transpose(im).convert('RGB')
        elif sh['kind'] != 'anchor':
            raise ValueError(f'Unknown shot kind: {sh["kind"]}')
    if next_index != len(sentences):
        raise ValueError('Shot plan does not cover final sentences')
    end = sentences[-1]['end']+1.0
    cuts = [0.0]+[(sentences[ids[x['end']]]['end']+
                          sentences[ids[y['start']]]['start'])/2
                         for x, y in zip(shots, shots[1:])]+[end]
    frames = [round(t*FPS) for t in cuts[:-1]]+[math.ceil(end*FPS)]
    if any(y <= x for x, y in zip(frames, frames[1:])):
        raise ValueError('Shot is shorter than one frame')
    photo_time = sum((frames[i+1]-frames[i])/FPS for i, s in enumerate(shots) if s['kind']=='photo')
    if photo_time <= end/2:
        raise ValueError('Photographs must occupy most of the runtime')
    anchors = []
    for name in ('closed', 'half', 'open'):
        p = Path('/workspace/fn3') / f'full_{name}.png'
        with Image.open(p) as im:
            if im.size != SIZE:
                raise ValueError(f'Wrong anchor dimensions: {p}')
            anchors.append(im.convert('RGB'))
    info = sf.info(a.wav)
    if info.duration+0.05 < sentences[-1]['end']:
        raise ValueError('Audio ends before the final sentence')
    return plan, words, end, frames, photos, anchors


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ep', required=True, choices=['ep01', 'ep02', 'ep03'])
    for name in ('wav', 'meta', 'shots', 'out'):
        p.add_argument('--'+name, required=True, type=Path)
    p.add_argument('--photos', type=Path, default=ROOT/'photos')
    p.add_argument('--dry-run', action='store_true', help='Validate assets/timing; encode nothing')
    a = p.parse_args()
    if not shutil.which('ffmpeg'):
        raise RuntimeError('ffmpeg is required')
    plan, words, end, bounds, photos, anchors = load_inputs(a)
    overlay = make_overlay(plan['title'], plan['part'], BUILD/f'{a.ep}_lower_third.png')
    captions = [(s, e, text_patch(t)) for s, e, t in chunks(words)]
    credits = {i: text_patch(sh['credit'], True) for i, sh in enumerate(plan['shots']) if sh['kind']=='photo'}
    print(f'{a.ep}: {end:.3f}s, {bounds[-1]} frames, {len(plan["shots"])} shots', flush=True)
    if a.dry_run:
        return
    a.out.parent.mkdir(parents=True, exist_ok=True)
    frames_dir = BUILD/'frames'
    frames_dir.mkdir(exist_ok=True)
    number = int(a.ep[2:])
    first_photo = next(i for i, sh in enumerate(plan['shots']) if sh['kind']=='photo')
    preview = [min(bounds[first_photo]+FPS, bounds[first_photo+1]-1),
               (bounds[-2]+bounds[-1])//2]
    starts = [c[0] for c in captions]
    with tempfile.TemporaryDirectory(prefix=f'{a.ep}_', dir=BUILD) as tmp:
        tmp = Path(tmp)
        # Decode locally to the same sample rate as the original RMS implementation.
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(a.wav), '-ar', str(SR),
                        '-ac', '1', str(tmp/'mono.wav')], check=True)
        mono, _ = sf.read(tmp/'mono.wav', dtype='float32')
        states = mouth_states(mono, words, bounds[-1])
        video = tmp/'video.mp4'
        cmd = ['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24',
               '-s', '1080x1920', '-r', str(FPS), '-i', '-', '-an', '-c:v', 'libx264',
               '-crf', '17', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', str(video)]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        try:
            for k, sh in enumerate(plan['shots']):
                print(f'  shot {k+1}/{len(plan["shots"])}: {sh["kind"]}', flush=True)
                for f in range(bounds[k], bounds[k+1]):
                    if sh['kind']=='anchor':
                        im = anchors[states[f]].convert('RGBA')
                    else:
                        im = photo_frame(photos[sh['file']], k,
                                         (f-bounds[k])/max(1, bounds[k+1]-bounds[k]-1),
                                         sh['file']=='oblock_map.png').convert('RGBA')
                    im.alpha_composite(overlay)
                    if k in credits:
                        c = credits[k]
                        im.alpha_composite(c, (0, 1504-c.height))
                    ci = bisect.bisect_right(starts, f/FPS)-1
                    if ci >= 0 and f/FPS < captions[ci][1]:
                        c = captions[ci][2]
                        im.alpha_composite(c, (0, 1350-c.height))
                    im = im.convert('RGB')
                    for j, target in enumerate(preview):
                        if f == target:
                            im.save(frames_dir/f'ep{number}_{"ab"[j]}.jpg', quality=94)
                    proc.stdin.write(im.tobytes())
            proc.stdin.close()
            if proc.wait():
                raise RuntimeError('Video encoder failed')
        except BaseException:
            proc.stdin.close()
            proc.terminate()
            proc.wait()
            raise
        # Preserve supplied audio; only pad/trim silence to the requested ending.
        staged = tmp/'final.mp4'
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(video), '-i', str(a.wav),
                        '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-af',
                        f'apad,atrim=duration={end:.9f}', '-c:a', 'aac', '-b:a', '192k',
                        '-ac', '2', '-ar', str(SR), '-t', f'{end:.9f}',
                        '-movflags', '+faststart', str(staged)], check=True)
        shutil.copyfile(staged, a.out)
    sheet = Image.new('RGB', (540, 480))
    for i, suffix in enumerate('ab'):
        with Image.open(frames_dir/f'ep{number}_{suffix}.jpg') as im:
            sheet.paste(im.resize((270, 480)), (270*i, 0))
    sheet.save(frames_dir/f'ep{number}_contact.jpg', quality=94)
    print(f'Wrote {a.out}', flush=True)

if __name__ == '__main__':
    main()
