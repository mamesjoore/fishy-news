# Extra format: Fish Files

This is a copy of the Fish Files episode builder (code and lower-third
PNGs only). It is **not** wired into `make_clip.py`, and the scripts still
contain the original `/workspace/fishlore` paths. Parameterize those
before running on another machine. Do not treat this as the default
format.

---

Run all available episodes offline:

```bash
/workspace/fishlore/build/run_all.sh
/workspace/fishlore/build/run_all.sh --dry-run
```

Inputs: `vo/ep01_final.wav` and `vo/ep01_final.json` (likewise ep02/ep03), the existing `scripts/epXX_shots.json`, photographs in `photos/`, and original `/workspace/fn3/full_{closed,half,open}.png`. Timings must already be in final WAV seconds; `time_scale` is provenance and is not applied again. No speech, images, or facts are generated. Missing inputs fail; the batch runner skips episodes missing final voice files.

Individual invocation (an explicitly supplied placeholder WAV is also accepted if its duration covers the timings):

```bash
python3 /workspace/fishlore/build/build_episode.py --ep ep01 \
  --wav /workspace/fishlore/vo/ep01_final.wav \
  --meta /workspace/fishlore/vo/ep01_final.json \
  --shots /workspace/fishlore/scripts/ep01_shots.json \
  --photos /workspace/fishlore/photos \
  --out /workspace/fishnews/fishfiles-ep1.mp4
```

Requires installed Python 3, Pillow, NumPy, soundfile, FFmpeg/libx264, fontconfig, Bebas Neue and Montserrat. Uses local files only. Dry-run validates timing, assets, photo majority and text layout, and writes the episode overlay without encoding video.

Outputs: `/workspace/fishnews/fishfiles-ep{1,2,3}.mp4`, `build/epXX_lower_third.png`, full-resolution preview stills `build/frames/ep1_a.jpg` / `ep1_b.jpg` (likewise ep2/ep3), and two-frame contact sheets `ep1_contact.jpg`. Temporary media stays in `build/` and is removed after rendering. Encoding is 1080×1920, 30 fps, H.264 CRF 17 / veryfast, yuv420p, AAC 192k stereo, faststart. Ending is last sentence end + 1 second; video frames round upward to the 30 fps grid (less than one frame difference). Captions preserve timing tokens exactly; a one-word sentence necessarily remains one word. Shot-plan captions remain editorial metadata; burned captions come only from the supplied word timings.
