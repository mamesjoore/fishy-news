# Extra format: Chicagomaxxing v2

This folder is a snapshot of the toilet-clip v2 builder, not the default
pipeline. `make_clip.py` does not use it.

`build.py.original` still has the old `/workspace/fn18` and `/workspace/fn14`
paths. The v2 look was: Channel 5 **5** cloned out of the anchor frames,
see-through Chicagomaxxing badge at top right (x=896, y=50, sky fill at 80%
opacity), Chicagomaxxing lower third, Ken Burns credited photos, padded
end card.

Default US-news clips stay on the Channel 5 **5** frames and the fn20
photo badge (`assets/brand/bug_fullframe.png`). Use this extra only when
you want the Chicagomaxxing brand, and parameterize the paths first.
