#!/usr/bin/env bash
set -euo pipefail
ROOT="${FISH_ANCHOR_ROOT:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
if [[ $# -lt 1 ]]; then echo "Usage: $0 clip.yaml [--photos photos/ --out out.mp4 --work work/name]" >&2; exit 2; fi
CLIP="$1"
shift
if [[ -n "${FISH_PYTHON:-}" ]]; then
  PY="$FISH_PYTHON"
elif [[ -x "$ROOT/.venv/bin/python" ]]; then
  PY="$ROOT/.venv/bin/python"
else
  PY="${PYTHON:-python3}"
fi
exec "$PY" "$ROOT/make_clip.py" --clip "$CLIP" "$@"
