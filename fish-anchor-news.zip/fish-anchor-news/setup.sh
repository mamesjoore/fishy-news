#!/usr/bin/env bash
set -euo pipefail
ROOT="${FISH_ANCHOR_ROOT:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
if ! command -v ffmpeg >/dev/null || ! command -v ffprobe >/dev/null; then
  if command -v apt-get >/dev/null; then
    if [[ $(id -u) == 0 ]]; then apt-get update; apt-get install -y ffmpeg; else sudo apt-get update; sudo apt-get install -y ffmpeg; fi
  else echo 'Install ffmpeg (including ffprobe), then rerun setup.' >&2; exit 1; fi
fi
# Python 3.11 or 3.12 supports this consistent, available CPU dependency pair.
BOOTSTRAP="${BOOTSTRAP_PYTHON:-python3}"
if [[ -z ${FISH_PYTHON:-} ]]; then
  "$BOOTSTRAP" -c 'import sys; assert (3,10)<=sys.version_info[:2]<=(3,12), "Use BOOTSTRAP_PYTHON=python3.11 (or 3.12); install python venv support first"'
  [[ -x "$ROOT/.venv/bin/python" ]] || "$BOOTSTRAP" -m venv "$ROOT/.venv"
  FISH_PYTHON="$ROOT/.venv/bin/python"
  "$FISH_PYTHON" -m pip install --upgrade pip
  "$FISH_PYTHON" -m pip install torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cpu
  "$FISH_PYTHON" -m pip install -r "$ROOT/requirements.txt"
else
  "$FISH_PYTHON" -c 'import f5_tts,torch,torchaudio,yaml,PIL,librosa,soundfile'
fi
export FISH_PYTHON
SEEDVC_DIR="${SEEDVC_DIR:-$ROOT/third_party/seed-vc}"
REV=51383efd921027683c89e5348211d93ff12ac2a8
if [[ ! -f "$SEEDVC_DIR/inference.py" ]]; then
  mkdir -p "$(dirname -- "$SEEDVC_DIR")"
  git clone https://github.com/Plachtaa/seed-vc "$SEEDVC_DIR"
  git -C "$SEEDVC_DIR" checkout "$REV"
fi
[[ $(git -C "$SEEDVC_DIR" rev-parse HEAD) == "$REV" ]] || { echo 'Seed-VC is at the wrong revision; supply the pinned clone.' >&2; exit 1; }
if git -C "$SEEDVC_DIR" apply --check "$ROOT/patches/seed-vc-soundfile.patch" 2>/dev/null; then
  git -C "$SEEDVC_DIR" apply "$ROOT/patches/seed-vc-soundfile.patch"
else
  git -C "$SEEDVC_DIR" apply --reverse --check "$ROOT/patches/seed-vc-soundfile.patch"
fi
if [[ -z ${SEEDVC_PYTHON:-} ]]; then
  [[ -x "$SEEDVC_DIR/.venv/bin/python" ]] || "$BOOTSTRAP" -m venv "$SEEDVC_DIR/.venv"
  SEEDVC_PYTHON="$SEEDVC_DIR/.venv/bin/python"
  "$SEEDVC_PYTHON" -m pip install --upgrade pip
  "$SEEDVC_PYTHON" -m pip install torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cpu
  # Keep the upstream requirements except explicit torch/CUDA/UI packages.
  "$FISH_PYTHON" - "$SEEDVC_DIR" <<'PY'
import re,sys
from pathlib import Path
p=Path(sys.argv[1])
lines=(p/'requirements.txt').read_text().splitlines()
(p/'.cpu-requirements.txt').write_text('\n'.join(x for x in lines if not re.match(r'\s*(torch(?:audio|vision)?|gradio(?:-client)?|nvidia[^= ]*|triton)(?:[<>=!~\s\[]|$)',x,re.I))+'\ntransformers==4.46.3\n')
PY
  "$SEEDVC_PYTHON" -m pip install -r "$SEEDVC_DIR/.cpu-requirements.txt"
fi
export SEEDVC_PYTHON SEEDVC_DIR
"$FISH_PYTHON" "$ROOT/fish_anchor/prefetch.py"
"$SEEDVC_PYTHON" "$ROOT/fish_anchor/prefetch.py" --seed
printf 'Setup complete. Run ./make_clip.sh tests/short_clip.yaml --photos tests --out out/smoke.mp4\n'
