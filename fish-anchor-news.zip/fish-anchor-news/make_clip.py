#!/usr/bin/env python3
"""The single public entry point for the reference clip pipeline."""
import argparse
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(os.environ.get('FISH_ANCHOR_ROOT', Path(__file__).resolve().parent)).resolve()


def load_clip(path, photos):
    import yaml
    cfg = yaml.safe_load(path.read_text())
    items = cfg.get('sentences')
    if items is None:
        script = (path.parent / cfg['script']).read_text()
        items = [dict(id=i, text=t.strip()) for i, t in
                 re.findall(r'^\*\*(s\d+)\*\*\s+(.+)$', script, re.M)]
    if not items or len({i['id'] for i in items}) != len(items):
        raise ValueError('Sentences must have unique ids and nonempty text')
    if any(not re.fullmatch(r'[A-Za-z0-9_-]+', i['id']) or not i['text'].strip() for i in items):
        raise ValueError('Invalid sentence id or empty text')
    cfg['items'] = items
    cfg['pauses'] = dict(default=0.4, head=0.12, tail=0.25, before={}) | cfg.get('pauses', {})
    ids = [i['id'] for i in items]
    previous = -1
    for shot in cfg['shots']:
        shot['sentence'] = shot.get('sentence', shot.get('id'))
        index = ids.index(shot['sentence'])
        if index <= previous or (previous == -1 and index != 0):
            raise ValueError('Shots must start at the first sentence and advance in order')
        previous = index
        for field in ('tag', 'line1', 'line2', 'footer'):
            assert isinstance(cfg['heads'][shot['head']][field], str)
        if shot.get('photo'):
            photo = (photos / shot['photo']).resolve()
            if not photo.is_file():
                raise FileNotFoundError(photo)
            if not shot.get('credit'):
                raise ValueError('Each photo needs an on-screen credit')
            shot['photo'] = str(photo)
    return cfg


def qa(work, out):
    from PIL import Image, ImageDraw
    m = json.loads((work / 'build/timeline.json').read_text())
    shots = m['shots']
    sheet = Image.new('RGB', (1080, math.ceil(len(shots)/4)*510), '#152438')
    draw = ImageDraw.Draw(sheet)
    for i, shot in enumerate(shots):
        t = (shot['start'] + shot['end'])/2
        data = subprocess.check_output(['ffmpeg', '-v', 'error', '-ss', str(t), '-i', str(out),
            '-frames:v', '1', '-vf', 'scale=270:480', '-f', 'image2pipe', '-vcodec', 'mjpeg', '-threads', '1', '-'])
        x, y = i % 4 * 270, i // 4 * 510
        sheet.paste(Image.open(io.BytesIO(data)), (x,y))
        draw.text((x+5,y+484), f"{t:.2f}s {Path(shot['photo']).name if shot['photo'] else 'anchor'}", fill='white')
    sheet.save(work/'build/contact-sheet.jpg', quality=90)
    duration = float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration',
        '-of','default=noprint_wrappers=1:nokey=1',str(out)], text=True))
    (work/'build/durations.txt').write_text(f'{out}\nffprobe: {duration:.6f}s\nplanned: {m["duration"]:.6f}s\nlast word: {m["last_word"]:.6f}s\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--clip', required=True, type=Path)
    parser.add_argument('--photos', type=Path, default=Path('photos'))
    parser.add_argument('--out', type=Path, default=Path('out.mp4'))
    parser.add_argument('--work', type=Path)
    default_python = os.environ.get('FISH_PYTHON') or (str(ROOT/'.venv/bin/python') if (ROOT/'.venv/bin/python').exists() else sys.executable)
    parser.add_argument('--python', default=default_python)
    parser.add_argument('--seedvc-dir', type=Path, default=Path(os.environ.get('SEEDVC_DIR', ROOT/'third_party/seed-vc')))
    parser.add_argument('--seedvc-python', default=os.environ.get('SEEDVC_PYTHON'))
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    # Re-exec before importing third-party dependencies, including for `python make_clip.py`.
    target = Path(shutil.which(args.python) or args.python).resolve()
    if not target.exists():
        raise FileNotFoundError(f'Python not found: {args.python}. Run ./setup.sh or set FISH_PYTHON.')
    if Path(sys.executable).resolve() != target:
        os.execv(str(target), [str(target), str(Path(__file__).resolve()), *sys.argv[1:]])
    cfg = load_clip(args.clip.resolve(), args.photos.resolve())
    name = re.sub(r'[^A-Za-z0-9_-]+', '-', args.clip.resolve().parent.name+'-'+args.clip.stem)
    work = (args.work or Path('work')/name).resolve()
    voice = dict(prompt='P3', sps=4.9, comma=0.25, seeds=[11], nfe=32, cfg=2.0)
    overrides = cfg.get('voice', {})
    if set(overrides) - set(voice):
        raise ValueError('Unknown voice override')
    voice.update(overrides)
    if voice['prompt'] != 'P3' or voice['nfe'] != 32 or voice['cfg'] != 2.0:
        raise ValueError('P3, nfe=32 and cfg=2.0 are fixed to preserve the voice')
    if args.validate_only:
        print(f"Valid: {len(cfg['items'])} sentences, {len(cfg['shots'])} shots")
        return
    work.mkdir(parents=True, exist_ok=True)
    # A lock prevents two processes sharing a work directory; changed input cannot reuse stale takes.
    import fcntl
    lock = (work/'.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    signature = hashlib.sha256(json.dumps(dict(cfg=cfg,voice=voice,device=os.environ.get('F5_DEVICE','cpu')), sort_keys=True).encode()).hexdigest()
    stamp = work/'input.sha256'
    if stamp.exists() and stamp.read_text() != signature:
        raise ValueError('Inputs changed: choose a fresh --work directory to avoid stale audio')
    stamp.write_text(signature)
    for d in ('takes','vo/vc','build'):
        (work/d).mkdir(parents=True, exist_ok=True)
    voice.update(items=cfg['items'], outdir=str(work/'takes'))
    def save(name, data):
        path=work/name; path.write_text(json.dumps(data,indent=2)); return str(path)
    config=save('clip.json',cfg); generation=save('generation.json',voice); pauses=save('pauses.json',cfg['pauses'])
    env = os.environ.copy(); env['PYTHONUNBUFFERED']='1'; env['FISH_ANCHOR_ROOT']=str(ROOT)
    def stage(label, command, cwd=None):
        print(f'\n[{label}]', flush=True)
        subprocess.run([str(x) for x in command], check=True, cwd=cwd, env=env)
    def script(label, name, *arguments):
        stage(label,[args.python, ROOT/'fish_anchor'/f'{name}.py',*arguments])
    f5=work/'vo/f5'; final=work/'vo/final'
    script('1/6 F5 P3 sentences','gen_f5',generation)
    script('2/6 Assemble and align','assemble',generation,pauses,f5)
    seedpython=args.seedvc_python or str(args.seedvc_dir.resolve()/'.venv/bin/python')
    stage('3/6 Seed-VC (CPU can take many hours)',[seedpython,'inference.py','--source',str(f5)+'.wav',
        '--target',ROOT/'assets/voice/vc_ref.wav','--output',work/'vo/vc','--diffusion-steps','25',
        '--length-adjust','1.0','--inference-cfg-rate','0.7'], args.seedvc_dir.resolve())
    wavs=list((work/'vo/vc').rglob('*.wav'))
    if not wavs: raise RuntimeError('Seed-VC produced no wav')
    vc=max(wavs,key=lambda p:p.stat().st_mtime_ns)
    script('4/6 Finalize timestamps','finalize',str(f5)+'.wav',vc,str(f5)+'.json',final)
    out=args.out.resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    script('5/6 Render','build',str(final)+'.wav',str(final)+'.json',out,config,work/'build')
    print('\n[6/6 Contact sheet and duration]',flush=True); qa(work,out)
    print(f'Done: {out}\nQA: {work / "build"}')

if __name__ == '__main__':
    main()
