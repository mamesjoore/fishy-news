# Assets

Do not recompress or replace these files if you want the same look and voice.

| Path | Source | Role |
| --- | --- | --- |
| `anchor/full_{closed,half,open}.png` | `/workspace/fn14` (used by the fn20 US-news build) | Channel 5 fish-anchor mouth frames. A lower third is already baked into the stills; the renderer covers it with a new opaque lower third. The yellow **5** bug is part of the frame. |
| `voice/vc_ref.wav` | `/workspace/fn3` | Seed-VC target. This is the cloned anchor voice. |
| `f5/P3.wav`, `f5/P3.txt`, `f5/texts.json` | `/workspace/fn16/prompts` | F5-TTS prompt: the Bikini Bottom news-update line. Prompt id is **P3**. |
| `brand/bug_fullframe.png` | `/workspace/video_lab/brand` | Full-frame overlay of the Chicagomaxxing badge, composited on **photo** shots only, as fn20 did. |
| `brand/logo_badge.png` | `/workspace/video_lab/assets` | Circular skyline badge drawn in the lower-third footer. |
| `brand/credit_fullframe.png` | `/workspace/video_lab/brand` | Historical credit-strip sample; credits are rendered live from `clip.yaml`. |
| `fonts/BigShoulders-VariableFont_opsz,wght.ttf` | Google Fonts, SIL OFL | Lower-third display type. |
| `fonts/CourierPrime-Regular.ttf`, `CourierPrime-Bold.ttf` | Google Fonts, SIL OFL | Photo credit type. |

Model weights are **not** assets. `setup.sh` downloads them into the Hugging Face cache.
