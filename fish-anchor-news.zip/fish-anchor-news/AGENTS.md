# Agent instructions (Codex)

You are helping the owner make Channel 5 fish-anchor news clips with
**this repository's pipeline only**. Do not invent a new voice, a new
mouth system, or a new compositor.

## Voice (do not change)

The only voice path is:

1. F5-TTS `F5TTS_v1_Base`, prompt **P3**, seed **11**, `nfe=32`,
   `cfg=2.0`, `sway_sampling_coef=-1`, `speed=1.0`,
   `remove_silence=False`, `sps=4.9`, `comma=0.25`.
2. Seed-VC at commit `51383efd921027683c89e5348211d93ff12ac2a8` with
   `--diffusion-steps 25 --length-adjust 1.0 --inference-cfg-rate 0.7`
   and `assets/voice/vc_ref.wav` as the target. Do not pass extra flags.
3. `fish_anchor/finalize.py` as implemented (scale timestamps only).

Do not add ElevenLabs or any other TTS. Do not retune seeds, NFE, CFG,
or Seed-VC flags. Do not rewrite the RMS mouth-state logic in
`fish_anchor/build.py`.

## How to make a clip

1. Research 3–4 real stories from named sources. Do not invent facts,
   quotes, numbers, or outcomes. Prefer alleged / police-said /
   "the Times reported" framing.
2. Download clearly licensed stills (Wikimedia, official portraits).
   Write `SOURCES.md` with file name, on-screen credit, URL, and license.
3. Write `script.md` as a straight news-anchor read:
   - No "youse". No corny jokes. Small dry quips only, and never about
     victims.
   - Hook, then packages, short fish transitions, sign-off.
   - The fish is only on the hook, transitions, and sign-off.
4. Write `clip.yaml` following `examples/us-2026-11-15/clip.yaml`:
   sentences (or a `script:` pointing at `script.md`), `pauses`, `heads`,
   and `shots`. Default pauses are `default: 0.4`, `head: 0.12`,
   `tail: 0.25`. Use `before: {sXX: 0.7}` on transition and sign-off
   sentences. Every photo shot needs a `credit`.
5. Run only this entry point:

   ```bash
   ./make_clip.sh clip.yaml --photos photos/ --out out/clip.mp4
   ```

   Give each run its own `--work` directory.
6. QA `work/*/build/contact-sheet.jpg` and `durations.txt`: opaque lower
   thirds, visible credits, closed mouth for the last second, ending not
   chopped, fish only on hook/transitions/sign-off, cloned voice.

## Rules

- Do not commit secrets, `.env`, API keys, model weights, venvs, or
  rendered `*.mp4`.
- Do not publish the anchor frames or voice wavs.
- Do not modify `/workspace/fishlore` or any paused job if you are on
  the shared box.
- If setup is already done, reuse `FISH_PYTHON`, `SEEDVC_DIR`,
  `SEEDVC_PYTHON`, and `HF_HOME` instead of redownloading weights.
