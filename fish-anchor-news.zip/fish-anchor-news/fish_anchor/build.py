#!/usr/bin/env python3
"""Render finalized VO with timed anchor inserts and credited moving stills."""
import sys, json, subprocess, math
from pathlib import Path
import numpy as np
import soundfile as sf
from PIL import Image
sys.dont_write_bytecode = True
from paths import ROOT
from lower_third import render_lower_third, render_credit_fullframe
FPS=30; SR=48000
def concat_path(path):
    return str(path).replace("'", "'\\''")

def run(args): subprocess.run(args,check=True)
def main():
    VO,META,OUT,CONFIG,WORK=sys.argv[1:6]
    cfg=json.loads(Path(CONFIG).read_text()); B=Path(WORK); B.mkdir(parents=True,exist_ok=True)
    HEADS={k:tuple(v[x] for x in ("tag","line1","line2","footer")) for k,v in cfg["heads"].items()}
    m=json.loads(Path(META).read_text()); S={s['id']:s for s in m['sentences']}; Wd=m['words']
    last=max(w['e'] for w in Wd); END=last+1.0
    nframes=math.ceil(END*FPS); END=nframes/FPS
    # Decode to the same sample rate as fn16; no time-stretch.
    run(['ffmpeg','-v','error','-y','-i',VO,'-ac','1','-ar',str(SR),str(B/'decoded.wav')])
    y,_=sf.read(B/'decoded.wav',dtype='float32'); vo=np.zeros(round(END*SR),np.float32)
    vo[:min(len(y),len(vo))]=y[:min(len(y),len(vo))]; sf.write(B/'vo_track.wav',vo,SR)
    # Exact mouth-state logic from the reference build.
    win=[(w['s'], w['e']) for w in Wd]
    hop=SR//FPS; nf=int(np.ceil(END*FPS))
    env=np.array([np.sqrt(np.mean(vo[i*hop:(i+1)*hop]**2)+1e-12) for i in range(nf)])
    envdb=20*np.log10(env+1e-9); gmax=np.percentile(envdb[envdb>-60],95)
    st=np.zeros(nf,int)
    for i in range(nf):
        tt=(i+0.5)/FPS
        if not any(a-0.02<=tt<=b+0.02 for a,b in win): continue
        lm=envdb[max(0,i-5):i+6].max(); e=envdb[i]
        st[i]=0 if e<gmax-30 else (2 if (e>lm-5 and e>gmax-17) else (1 if e>gmax-24 else 0))
    i=0
    while i<nf:
        j=i
        while j<nf and st[j]==st[i]: j+=1
        if j-i<2 and i>0: st[i:j]=st[i-1]
        i=j
    # Enforce closed mouth for every frame after the final aligned word.
    st[int(math.ceil(last*FPS)):]=0
    (B/'mouth.json').write_text(json.dumps(dict(states=st.tolist())))
    ids=[s['id'] for s in m['sentences']]
    plan=[(ids.index(shot['sentence']),shot.get('photo'),shot['head']) for shot in cfg['shots']]
    cuts=[0]+[round((m['sentences'][k-1]['end']+m['sentences'][k]['start'])/2*FPS) for k,_,_ in plan[1:]]+[nframes]
    timeline=[]; segs=[]
    for idx,(sid,photo,head) in enumerate(plan):
        f0,f1=cuts[idx:idx+2]; n=f1-f0; assert n>0
        overlay=render_lower_third(*HEADS[head])
        assert overlay.getchannel('A').crop((0,1536,1080,1920)).getextrema()==(255,255)
        if photo:
            overlay.alpha_composite(Image.open(ROOT/'assets/brand/bug_fullframe.png').convert('RGBA'))
            overlay.alpha_composite(render_credit_fullframe(text=cfg['shots'][idx]['credit']))
        ov=B/f'overlay_{idx}.png'; overlay.save(ov)
        out=B/f'seg_{idx:02}.mp4'
        base=['ffmpeg','-v','error','-y','-threads','2']
        if photo:
            # A high-resolution zoompan avoids one-pixel stepping during a slow push.
            vf=f"[0:v]scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,zoompan=z='1+0.055*on/{max(n-1,1)}':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d={n}:s=1080x1920:fps=30[v];[v][1:v]overlay=0:0,format=yuv420p"
            args=base+['-i',str(photo),'-i',str(ov),'-filter_complex_threads','1','-filter_complex',vf]
        else:
            names=[]
            for state,name in enumerate(['closed','half','open']):
                im=Image.open(ROOT/f'assets/anchor/full_{name}.png').convert('RGBA'); im.alpha_composite(overlay)
                dest=B/f'anchor_{idx}_{state}.png'; im.convert('RGB').save(dest); names.append(dest)
            listing=B/f'anchor_{idx}.txt'
            listing.write_text(''.join(f"file '{concat_path(names[st[i]])}'\nduration {1/FPS:.9f}\n" for i in range(f0,f1))+f"file '{concat_path(names[0])}'\n")
            args=base+['-f','concat','-safe','0','-i',str(listing),'-vf','fps=30,format=yuv420p']
        run(args+['-frames:v',str(n),'-an','-c:v','libx264','-crf','16','-preset','medium','-threads','2',str(out)])
        segs.append(out); timeline.append(dict(start=f0/FPS,end=f1/FPS,photo=photo,head=head))
    (B/'segments.txt').write_text(''.join(f"file '{concat_path(p)}'\n" for p in segs))
    run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(B/'segments.txt'),'-i',str(B/'vo_track.wav'),'-map','0:v','-map','1:a','-c:v','copy','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-ar','48000','-ac','2','-c:a','aac','-b:a','192k','-t',str(END),'-movflags','+faststart',OUT])
    (B/'timeline.json').write_text(json.dumps(dict(duration=END,last_word=last,shots=timeline),indent=2))
    print(OUT,END,flush=True)
if __name__=='__main__': main()
