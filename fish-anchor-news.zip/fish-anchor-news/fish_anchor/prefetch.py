"""Cache weights without replacing any existing Hugging Face cache configuration."""
import sys
from huggingface_hub import snapshot_download


def fetch(repo, **kwargs):
    try:
        return snapshot_download(repo, local_files_only=True, **kwargs)
    except Exception:
        return snapshot_download(repo, **kwargs)


if '--seed' in sys.argv:
    fetch('Plachta/Seed-VC')
    fetch('funasr/campplus')
    fetch('openai/whisper-small')
    fetch('nvidia/bigvgan_v2_22khz_80band_256x')
else:
    fetch('SWivid/F5-TTS', revision='84e5a410d9cead4de2f847e7c9369a6440bdfaca',
          allow_patterns=['F5TTS_v1_Base/*'])
    fetch('charactr/vocos-mel-24khz')
    # These are also required by the unchanged take selection and forced aligner.
    from torchaudio.pipelines import WAV2VEC2_ASR_LARGE_960H, MMS_FA
    WAV2VEC2_ASR_LARGE_960H.get_model()
    MMS_FA.get_model(with_star=False)
