import sys,torch,torchaudio,librosa,re,json
from torchaudio.pipelines import WAV2VEC2_ASR_LARGE_960H as B
m=B.get_model().eval(); L=B.get_labels()
def rec(f):
    a,_=librosa.load(f,sr=16000)
    with torch.inference_mode(): em,_=m(torch.tensor(a)[None])
    ids=em[0].argmax(-1).tolist(); out=[];prev=None
    for i in ids:
        if i!=prev and i!=0: out.append(L[i])
        prev=i
    return ''.join(out).replace('|',' ').strip().lower()
def cer(ref,hyp):
    import difflib
    r=re.sub(r"[^a-z' ]","",ref.lower().replace('-',' ')); r=re.sub(r"\s+"," ",r).strip()
    h=re.sub(r"\s+"," ",hyp).strip()
    # levenshtein on words
    a=r.split(); b=h.split()
    d=list(range(len(b)+1))
    for i in range(1,len(a)+1):
        p=d[:]; d[0]=i
        for j in range(1,len(b)+1): d[j]=min(p[j]+1,d[j-1]+1,p[j-1]+(a[i-1]!=b[j-1]))
    return d[len(b)]/max(1,len(a))
if __name__=="__main__":
    ref=sys.argv[1]
    for f in sys.argv[2:]:
        h=rec(f); print(f"{cer(ref,h):.2f}",f,'|',h,flush=True)
