import os
from pathlib import Path
ROOT = Path(os.environ.get("FISH_ANCHOR_ROOT", Path(__file__).resolve().parents[1])).resolve()
