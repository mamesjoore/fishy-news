import re
def syl(w):
    w=re.sub(r"[^a-z]","",w.lower())
    if not w: return 0
    if w.isdigit(): return 2
    g=re.findall(r"[aeiouy]+",w); n=len(g)
    if w.endswith("e") and not w.endswith(("le","ee","ye")) and n>1: n-=1
    if w.endswith(("ed")) and not w.endswith(("ted","ded")) and n>1: n-=1
    if re.search(r"(ia|io|eo|ua)",w) and not w.endswith("tion") and not w.endswith("sion") : n+=0
    return max(1,n)
