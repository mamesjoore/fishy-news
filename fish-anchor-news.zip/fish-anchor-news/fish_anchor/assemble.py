"""Pick best take per sentence (wav2vec2 WER), trim, join with study pauses, word-align. usage: assemble.py cfg.json pauses.json out_prefix"""
import sys,json,glob,re,numpy as np,librosa,soundfile as sf
from asr2 import rec,cer
from align import align_words,norm
cfg=json.load(open(sys.argv[1])); pauses=json.load(open(sys.argv[2])); outp=sys.argv[3]
SR=48000; HEAD=float(pauses.get('head',0.12)); TAIL=float(pauses.get('tail',0.25))
parts=[np.zeros(int(HEAD*SR),np.float32)]; cur=HEAD; words=[]; sents=[]; picks=[]
for i,it in enumerate(cfg['items']):
    best=None
    for f in sorted(glob.glob(f"{cfg['outdir']}/{it['id']}_s*.wav")):
        h=rec(f); e=cer(it['text'],h)
        print(f"  {it['id']} {f} wer={e:.2f} | {h}",flush=True)
        if best is None or e<best[0]: best=(e,f,h)
    picks.append(dict(id=it['id'],file=best[1],wer=best[0],asr=best[2]))
    y,_=librosa.load(best[1],sr=SR)
    yt,idx=librosa.effects.trim(y,top_db=40)
    a=max(0,idx[0]-int(0.02*SR)); b=min(len(y),idx[1]+int(0.03*SR)); yt=y[a:b].copy()
    f=int(0.008*SR); yt[:f]*=np.linspace(0,1,f); yt[-f:]*=np.linspace(1,0,f)
    y16=librosa.resample(yt,orig_sr=SR,target_sr=16000)
    toks=[w for w in re.split(r"\s+",it['text'].replace('—',' ')) if norm(w)]
    W0=align_words(y16,toks,offset=0.0); lead=W0[0]['s']
    if i>0:
        p=float(pauses['before'][it['id']]) if it['id'] in pauses['before'] else float(pauses['default'])
        sil=max(0.04,p-prev_trail-lead)   # target = audible gap between words, as measured in the reference
        parts.append(np.zeros(int(sil*SR),np.float32)); cur+=sil
    prev_trail=len(yt)/SR-W0[-1]['e']
    W=[dict(w,s=w['s']+cur,e=w['e']+cur) for w in W0]
    for w in W: w['sent']=i
    words+=W
    sents.append(dict(id=it['id'],text=it['text'],start=round(cur,4),end=round(cur+len(yt)/SR,4)))
    parts.append(yt.astype(np.float32)); cur+=len(yt)/SR
parts.append(np.zeros(int(TAIL*SR),np.float32))
y=np.concatenate(parts); sf.write(outp+'.wav',y,SR)
json.dump(dict(duration=len(y)/SR,sentences=sents,words=words,picks=picks),open(outp+'.json','w'),indent=1)
print('wrote',outp,len(y)/SR,[ (p['id'],round(p['wer'],2)) for p in picks])
