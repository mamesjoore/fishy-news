import sys,json,librosa,soundfile as sf,numpy as np
src,vcw,meta,out=sys.argv[1:5]
m=json.load(open(meta)); SR=48000
y,_=librosa.load(vcw,sr=SR); d0=sf.info(src).duration; k=(len(y)/SR)/d0
for w in m['words']: w['s']*=k; w['e']*=k
for s in m['sentences']: s['start']=round(s['start']*k,4); s['end']=round(s['end']*k,4)
m['duration']=len(y)/SR; m['time_scale']=k
sf.write(out+'.wav',y,SR); json.dump(m,open(out+'.json','w'),indent=1); print(out,len(y)/SR,'scale',k)
