"""F5-TTS sentence-by-sentence generation with duration set from the cadence study."""
import sys,time,json,re,os
import torch,torchaudio,soundfile as sf
def _load(p,*a,**k):
    x,sr=sf.read(p,dtype='float32',always_2d=True); return torch.from_numpy(x.T.copy()),sr
torchaudio.load=_load
from syllables import syl
from paths import ROOT
from f5_tts.api import F5TTS
cfg=json.load(open(sys.argv[1]))   # {prompt, outdir, sps, comma, items:[{id,text}], seeds:[...]}
os.makedirs(cfg['outdir'],exist_ok=True)
f=F5TTS(model="F5TTS_v1_Base",device=os.environ.get("F5_DEVICE", "cpu"))
texts=json.load(open(ROOT/'assets/f5/texts.json'))
P=cfg['prompt']; ref=str(ROOT/f'assets/f5/{P}.wav'); rlen=sf.info(ref).duration
for it in cfg['items']:
    t=it['text']
    n=sum(syl(w) for w in t.split()); c=len(re.findall(r",|—|\.\.\.",t))
    gd=n/cfg['sps']+c*cfg['comma']+0.2
    for seed in it.get('seeds',cfg.get('seeds',[11])):
        out=f"{cfg['outdir']}/{it['id']}_s{seed}.wav"
        if os.path.exists(out): continue
        t0=time.time()
        wav,sr,_=f.infer(ref_file=ref,ref_text=texts[P]+" ",gen_text=t,nfe_step=cfg.get('nfe',32),cfg_strength=cfg.get('cfg',2.0),
                         sway_sampling_coef=-1,speed=1.0,fix_duration=rlen+gd,remove_silence=False,file_wave=out,seed=seed)
        print(it['id'],seed,f"syl={n} target={gd:.2f} got={len(wav)/sr:.2f} t={time.time()-t0:.0f}s",flush=True)
