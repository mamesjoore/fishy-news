#!/usr/bin/env python3
"""Chicagomaxxing broadcast lower third and branding pack helpers.

Geometry is copied from historical-reference (the script that built
the bean-v10 panel.png) and confirmed against
historical-reference frames and historical-reference

    render_lower_third(tag, line1, line2, footer) -> PIL RGBA 1080x1920
"""
from __future__ import annotations

import math
import os
import random
from pathlib import Path

from paths import ROOT

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageChops

DIR = Path(__file__).resolve().parent
ASSETS = DIR.parent / "assets"

# --- canvas ---
W, H = 1080, 1920
FPS = 30

# --- bars: exact mkvert.py / panel.png boxes ---
# mkvert.py draws:
#   rectangle((0, 1536, 1080, 1920), navy)
#   rectangle((0, 1536, 1080, 1626), red tag)
#   rectangle((0, 1626, 1080, 1800), white)
# Pillow fill includes the end coordinate when it is in-bounds, so:
BAR_TOP = 1536          # first opaque row (inclusive)
BAR_BOTTOM = 1919       # last opaque row (inclusive)
TAG_Y0, TAG_Y1 = 1536, 1625       # inclusive; 90 px
WHITE_Y0, WHITE_Y1 = 1626, 1800   # inclusive; 175 px
FOOTER_Y0, FOOTER_Y1 = 1801, 1919 # inclusive; 119 px
# Same rectangle args as mkvert.py (kept for drop-in fidelity):
RECT_NAVY = (0, 1536, 1080, 1920)
RECT_TAG = (0, 1536, 1080, 1626)
RECT_WHITE = (0, 1626, 1080, 1800)

# Text anchors from mkvert.py (anchor='lm'):
TAG_TEXT_Y = 1581       # vertical center of 90 px tag bar
LINE1_Y = 1672
LINE2_Y = 1756
FOOTER_TEXT_Y = 1860    # vertical center of 119 px footer
TEXT_X = 40             # mkvert left margin; shifted when a star/badge is present

# --- corner bug (compositor box, inclusive pixel coords) ---
# Source paste in mkvert.py was (36, 48) at 150 x 158.
# After encode, the visible '5' on bean-v10 is x 39-182, y 50-201.
# Measured yellow bbox including AA: (32, 50, 183, 201), 152 x 152.
BUG_X, BUG_Y, BUG_W, BUG_H = 39, 50, 144, 152   # 39..182, 50..201 inclusive
# Circular badge used to cover the rounded-square '5' plus its AA halo:
BUG_CIRCLE = 152
BUG_CIRCLE_X = 32   # 32 + 152 - 1 = 183, matches measured halo
BUG_CIRCLE_Y = 50   # 50 + 152 - 1 = 201

# --- credit strip (sits just above the lower third, right-aligned) ---
CREDIT_BOTTOM = 1528    # 8 px gap above y=1536
CREDIT_RIGHT = 1040
CREDIT_PAD_X, CREDIT_PAD_Y = 18, 10

# --- colors ---
PAPER_BLUE = (178, 204, 226)      # zine2 paper bg #b2cce2
PAPER_BLUE_ALT = (169, 198, 224)  # requested #a9c6e0
CREAM = (243, 234, 210)           # #f3ead2
CREAM_INK = (240, 236, 226)       # zine headline cream
FLAG_RED = (228, 0, 43)           # Chicago flag red #e4002b
BADGE_BLUE = (130, 203, 254)      # sky fill of logo_badge.png #82cbfe
NEAR_BLACK = (15, 15, 15)
FOOTER_BLUE = (16, 36, 56)        # darkened paper-blue, broadcast contrast
FOOTER_TEXT = (243, 234, 210)
WHITE = (255, 255, 255)

# --- fonts ---
FONT_DIR = ROOT / 'assets/fonts'
BIG_SHOULDERS = str(FONT_DIR / 'BigShoulders-VariableFont_opsz,wght.ttf')
COURIER_PRIME = str(FONT_DIR / 'CourierPrime-Regular.ttf')
COURIER_PRIME_BOLD = str(FONT_DIR / 'CourierPrime-Bold.ttf')
BADGE_PATH = ROOT / 'assets/brand/logo_badge.png'

# Big Shoulders Black at these sizes matches Anton 62/64 cap-height
# (Anton 62 cap 53 px, Anton 64 cap 56 px; BS 66/70 cap 53/56).
TAG_SIZE = 66
LINE_SIZE = 70
FOOTER_SIZE = 40
CREDIT_SIZE = 24


def font(path: str, size: int, axes: list[float] | None = None) -> ImageFont.FreeTypeFont:
    fo = ImageFont.truetype(path, size)
    if axes:
        try:
            fo.set_variation_by_axes(axes)
        except Exception:
            pass
    return fo


def big_shoulders(size: int, weight: int = 900) -> ImageFont.FreeTypeFont:
    # fvar axis order is wght, opsz (default opsz=72, the display size).
    return font(BIG_SHOULDERS, size, [weight])


def circular_badge(size: int) -> Image.Image:
    """Resize the skyline seal to a square with transparent corners preserved."""
    src = Image.open(BADGE_PATH).convert("RGBA")
    # Tight box of opaque pixels, then scale uniformly to `size`.
    bbox = src.getchannel("A").point(lambda a: 255 if a > 16 else 0).getbbox()
    if bbox:
        src = src.crop(bbox)
    return src.resize((size, size), Image.Resampling.LANCZOS)


def rounded_bug(size: int = BUG_CIRCLE, radius: int = 18) -> Image.Image:
    """Circular seal on an opaque rounded-rect backing that covers the old '5'.

    The source '5' is a yellow rounded square (~radius 16). A bare circle
    leaves those corners peeking through, so the backing is the badge sky
    blue, drawn at 2x and downsampled for clean edges.
    """
    scale = 2
    S, R = size * scale, radius * scale
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, S - 1, S - 1), radius=R, fill=BADGE_BLUE + (255,))
    im.alpha_composite(circular_badge(S))
    return im.resize((size, size), Image.Resampling.LANCZOS)


def six_point_star(size: int, fill=FLAG_RED, outline=None) -> Image.Image:
    """Chicago flag-style six-pointed star, point-up."""
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = (size - 1) / 2
    # Pointy Chicago star: outer/inner ratio ~0.38
    R, r = c, c * 0.38
    pts = []
    for i in range(12):
        rad = math.pi / 6 * i - math.pi / 2
        R0 = R if i % 2 == 0 else r
        pts.append((c + R0 * math.cos(rad), c + R0 * math.sin(rad)))
    d.polygon(pts, fill=fill, outline=outline)
    return im


def _torn_lip(width: int, height: int, amp: int = 5, step: int = 7, seed: int = 312) -> Image.Image:
    """Opaque cream strip with a jagged bottom edge (stays inside the bar)."""
    rng = random.Random(seed)
    lip = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(lip)
    pts = [(0, 0), (width, 0)]
    # jagged bottom, always >= 2 px so the top row stays solid cream
    y_base = height - 1
    for x in range(width, -1, -step):
        pts.append((x, y_base - rng.uniform(0, amp)))
    pts.append((0, y_base - rng.uniform(0, amp)))
    d.polygon(pts, fill=CREAM + (255,))
    return lip


def _fit_text(text: str, size: int, max_w: int, weight: int = 900) -> ImageFont.FreeTypeFont:
    sz = size
    while sz >= 28:
        fo = big_shoulders(sz, weight)
        bb = fo.getbbox(text)
        if (bb[2] - bb[0]) <= max_w:
            return fo
        sz -= 2
    return big_shoulders(28, weight)


def render_lower_third(tag: str, line1: str, line2: str, footer: str) -> Image.Image:
    """Return a 1080x1920 RGBA overlay. Opaque pixels only in y=1536..1919."""
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)

    # Same three rectangles as fn3/mkvert.py, rebranded colors.
    d.rectangle(RECT_NAVY, fill=FOOTER_BLUE + (255,))
    d.rectangle(RECT_TAG, fill=FLAG_RED + (255,))
    d.rectangle(RECT_WHITE, fill=CREAM + (255,))

    # Torn-paper cream lip along the top of the tag, fully opaque, y>=1536.
    lip_h = 10
    lip = _torn_lip(W, lip_h, amp=5, step=7, seed=312)
    ov.alpha_composite(lip, (0, BAR_TOP))

    # Red six-point Chicago star on a cream chip, left of the tag.
    chip_s = 52
    star_s = 36
    chip = Image.new("RGBA", (chip_s, chip_s), (0, 0, 0, 0))
    cd = ImageDraw.Draw(chip)
    m = 1
    cd.ellipse((m, m, chip_s - 1 - m, chip_s - 1 - m), fill=CREAM + (255,))
    star = six_point_star(star_s, fill=FLAG_RED)
    off = (chip_s - star_s) // 2
    chip.alpha_composite(star, (off, off))
    chip_x = 28
    chip_y = TAG_TEXT_Y - chip_s // 2
    ov.alpha_composite(chip, (chip_x, chip_y))

    tag_x = chip_x + chip_s + 16
    tag_font = _fit_text(tag.upper(), TAG_SIZE, W - tag_x - 40)
    d = ImageDraw.Draw(ov)
    d.text((tag_x, TAG_TEXT_Y), tag.upper(), font=tag_font, fill=WHITE, anchor="lm")

    # Headlines on the cream bar.
    max_line_w = W - TEXT_X - 40
    f1 = _fit_text(line1.upper(), LINE_SIZE, max_line_w)
    f2 = _fit_text(line2.upper(), LINE_SIZE, max_line_w)
    d.text((TEXT_X, LINE1_Y), line1.upper(), font=f1, fill=NEAR_BLACK, anchor="lm")
    d.text((TEXT_X, LINE2_Y), line2.upper(), font=f2, fill=FLAG_RED, anchor="lm")

    # Footer: mini skyline badge + location line.
    badge_s = 64
    mini = circular_badge(badge_s)
    badge_x = 24
    badge_y = FOOTER_TEXT_Y - badge_s // 2
    # Keep the badge inside the footer band (1801..1919).
    badge_y = max(FOOTER_Y0 + 2, min(badge_y, FOOTER_Y1 - badge_s - 1))
    ov.alpha_composite(mini, (badge_x, badge_y))

    foot_x = badge_x + badge_s + 16
    foot_font = _fit_text(footer.upper(), FOOTER_SIZE, W - foot_x - 40, weight=700)
    d = ImageDraw.Draw(ov)
    d.text((foot_x, FOOTER_TEXT_Y), footer.upper(), font=foot_font, fill=FOOTER_TEXT, anchor="lm")

    # Safety: nothing opaque above the bar or past the frame.
    if BAR_TOP > 0:
        clear = Image.new("RGBA", (W, BAR_TOP), (0, 0, 0, 0))
        ov.paste(clear, (0, 0))
    return ov


def render_bug_fullframe() -> Image.Image:
    """1080x1920 transparent PNG with the badge covering the old '5' box."""
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ov.alpha_composite(rounded_bug(), (BUG_CIRCLE_X, BUG_CIRCLE_Y))
    return ov


def render_bug() -> Image.Image:
    """The bug at its native size (152x152 rounded square, opaque backing)."""
    return rounded_bug()


def render_credit_strip(text: str = "PHOTO: GIACOMO CAIN / BLOCK CLUB CHICAGO") -> Image.Image:
    """Tight cream chip with the credit line (not full-frame)."""
    fo = font(COURIER_PRIME_BOLD, CREDIT_SIZE)
    bb = fo.getbbox(text)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    w = tw + CREDIT_PAD_X * 2
    h = th + CREDIT_PAD_Y * 2
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=6, fill=CREAM + (230,))
    d.text((CREDIT_PAD_X - bb[0], CREDIT_PAD_Y - bb[1]), text, font=fo, fill=NEAR_BLACK)
    return im


def render_credit_fullframe(text: str = "PHOTO: GIACOMO CAIN / BLOCK CLUB CHICAGO") -> Image.Image:
    strip = render_credit_strip(text)
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    x = CREDIT_RIGHT - strip.size[0]
    y = CREDIT_BOTTOM - strip.size[1]
    # Guard: must not collide with the lower third.
    if y + strip.size[1] > BAR_TOP:
        y = BAR_TOP - strip.size[1] - 8
    x = max(20, x)
    y = max(0, y)
    ov.alpha_composite(strip, (x, y))
    return ov


def paper_bg(w: int = W, h: int = H, col=PAPER_BLUE) -> Image.Image:
    """Zine-style light-blue paper, same method as zine2.paperbg, at 1080x1920."""
    bg = Image.new("RGB", (w, h), col)
    noise = Image.effect_noise(bg.size, 50).convert("L")
    bg = Image.blend(bg, Image.merge("RGB", [noise, noise, noise]), 0.09)
    fib = (
        Image.effect_noise((w // 4, h // 4), 80)
        .convert("L")
        .resize((w, h), Image.Resampling.BICUBIC)
        .filter(ImageFilter.GaussianBlur(2))
    )
    bg = ImageChops.multiply(bg, Image.merge("RGB", [fib.point(lambda v: 235 + v // 12)] * 3))
    return bg.convert("RGBA")


def render_endcard() -> Image.Image:
    """Light-blue paper end card with the skyline badge, handle, and credit."""
    c = paper_bg()
    d = ImageDraw.Draw(c)

    badge_s = 680
    badge = circular_badge(badge_s)
    bx = (W - badge_s) // 2
    by = 260
    # Soft drop shadow under the seal.
    sh = Image.new("RGBA", (badge_s, badge_s), (0, 0, 0, 0))
    sh.putalpha(badge.split()[3].point(lambda a: int(a * 0.28)))
    sh = sh.filter(ImageFilter.GaussianBlur(18))
    c.alpha_composite(sh, (bx + 8, by + 14))
    c.alpha_composite(badge, (bx, by))

    # Handle and tagline, zine-adjacent but still broadcast-clean.
    handle = "@chicagomaxxing"
    hf = big_shoulders(86, 900)
    d = ImageDraw.Draw(c)
    d.text((W // 2, 1020), handle, font=hf, fill=NEAR_BLACK, anchor="mt")

    line = "FOLLOW FOR MORE CHICAGO"
    # Torn cream strip behind the tagline, slightly wider than the type.
    lf = big_shoulders(56, 800)
    bb = lf.getbbox(line)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    pad_x, pad_y = 36, 18
    sw, sh_h = tw + pad_x * 2, th + pad_y * 2
    strip = Image.new("RGBA", (sw, sh_h), (0, 0, 0, 0))
    # jagged (torn) rectangle
    rng = random.Random(312)
    step, amp = 8, 6
    pts = []
    for x in range(0, sw, step):
        pts.append((x, rng.uniform(0, amp)))
    for y in range(0, sh_h, step):
        pts.append((sw - 1 - rng.uniform(0, amp), y))
    for x in range(sw, -1, -step):
        pts.append((x, sh_h - 1 - rng.uniform(0, amp)))
    for y in range(sh_h, -1, -step):
        pts.append((rng.uniform(0, amp), y))
    mask = Image.new("L", (sw, sh_h), 0)
    ImageDraw.Draw(mask).polygon(pts, fill=255)
    fill = Image.new("RGBA", (sw, sh_h), FLAG_RED + (255,))
    fill.putalpha(mask)
    sx = (W - sw) // 2
    sy = 1135
    # shadow
    sm = Image.new("RGBA", (sw, sh_h), (0, 0, 0, 0))
    sm.putalpha(mask.point(lambda a: int(a * 0.3)))
    sm = sm.filter(ImageFilter.GaussianBlur(6))
    c.alpha_composite(sm, (sx + 4, sy + 6))
    c.alpha_composite(fill, (sx, sy))
    d = ImageDraw.Draw(c)
    d.text((W // 2, sy + sh_h // 2), line, font=lf, fill=CREAM_INK, anchor="mm")

    # Two small red stars flanking nothing else — one under the strip corners? skip, keep clean.
    star = six_point_star(44, fill=FLAG_RED)
    c.alpha_composite(star, (W // 2 - 22, sy + sh_h + 28))

    credit = "Photo: Giacomo Cain / Block Club Chicago"
    cf = font(COURIER_PRIME, 26)
    d = ImageDraw.Draw(c)
    d.text((W // 2, 1640), credit, font=cf, fill=(50, 50, 55), anchor="mt")
    return c


def compose_preview(anchor_path: str, out_path: str | Path) -> Image.Image:
    """Anchor frame with the new bug and lower third covering the old chrome."""
    base = Image.open(anchor_path).convert("RGBA")
    if base.size != (W, H):
        base = base.resize((W, H), Image.Resampling.LANCZOS)
    # Lower third first (covers old bars), then bug (covers the '5').
    # Use the toilet sample so the preview shows the rebranded story.
    lt = render_lower_third(
        "BREAKING NEWS",
        "CHICAGO'S FIRST SELF-CLEANING TOILET",
        "OPENS IN WICKER PARK",
        "CHICAGOMAXXING · POLISH TRIANGLE",
    )
    base.alpha_composite(lt)
    base.alpha_composite(render_bug_fullframe())
    return base


# --- pack builder ---------------------------------------------------------

TOILET = dict(
    tag="BREAKING NEWS",
    line1="CHICAGO'S FIRST SELF-CLEANING TOILET",
    line2="OPENS IN WICKER PARK",
    footer="CHICAGOMAXXING · POLISH TRIANGLE",
)


def build_pack(dest: Path | None = None, anchor_frame: str | None = None) -> dict:
    dest = Path(dest or DIR)
    dest.mkdir(parents=True, exist_ok=True)
    paths = {}

    bug = render_bug()
    p = dest / "bug.png"
    bug.save(p)
    paths["bug.png"] = p

    bug_ff = render_bug_fullframe()
    p = dest / "bug_fullframe.png"
    bug_ff.save(p)
    paths["bug_fullframe.png"] = p

    lt = render_lower_third(**TOILET)
    p = dest / "lower_third_toilet.png"
    lt.save(p)
    paths["lower_third_toilet.png"] = p

    credit = render_credit_strip()
    p = dest / "credit_strip.png"
    credit.save(p)
    paths["credit_strip.png"] = p

    credit_ff = render_credit_fullframe()
    p = dest / "credit_fullframe.png"
    credit_ff.save(p)
    paths["credit_fullframe.png"] = p

    end = render_endcard()
    p = dest / "endcard.png"
    end.convert("RGB").save(p, quality=95)
    # also keep an RGBA copy? PNG RGB is fine for the end card.
    paths["endcard.png"] = p

    if anchor_frame and os.path.exists(anchor_frame):
        prev = compose_preview(anchor_frame, dest / "preview.png")
        p = dest / "preview.png"
        prev.convert("RGB").save(p, quality=95)
        paths["preview.png"] = p

    return paths


if __name__ == "__main__":
    import sys

    anchor = sys.argv[1] if len(sys.argv) > 1 else None
    built = build_pack(DIR, anchor_frame=anchor)
    for k, v in built.items():
        print("wrote", v)
