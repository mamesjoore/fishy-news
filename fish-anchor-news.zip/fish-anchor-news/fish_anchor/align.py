import torch,torchaudio,re,librosa,numpy as np
from torchaudio.pipelines import MMS_FA as B
_m=None
def model():
    global _m
    if _m is None: _m=B.get_model(with_star=False).eval()
    return _m
DIC=B.get_dict(star=None)
def norm(w):
    return re.sub(r"[^a-z']","",w.lower().replace('-',' ').replace('—',' '))
def align_words(y16, words, offset=0.0):
    """y16: mono float 16k; words: list of display tokens. returns list of (word,start,end)"""
    toks=[];keep=[]
    for w in words:
        n=norm(w)
        if n: toks.append(n); keep.append(w)
    with torch.inference_mode():
        em,_=model()(torch.tensor(y16,dtype=torch.float32)[None])
    tgt=[DIC[c] for t in toks for c in t]
    al,sc=torchaudio.functional.forced_align(em,torch.tensor([tgt],dtype=torch.int32),blank=0)
    spans=torchaudio.functional.merge_tokens(al[0],sc[0].exp())
    ratio=len(y16)/16000/em.shape[1]
    out=[];i=0
    for w,t in zip(keep,toks):
        sp=spans[i:i+len(t)]; i+=len(t)
        out.append(dict(w=w,s=offset+sp[0].start*ratio,e=offset+sp[-1].end*ratio,score=float(np.mean([s.score for s in sp]))))
    return out
def align_text(wav, text, sr_in=None):
    y,_=librosa.load(wav,sr=16000)
    words=[w for w in re.split(r"\s+",text.replace('—',' ').replace('...','... ')) if norm(w)]
    return align_words(y,words)
