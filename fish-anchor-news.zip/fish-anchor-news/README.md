# fish-anchor-news

Private pipeline for Channel 5 fish-anchor news clips. It reproduces the
working fn20 build: the same SpongeBob-style Channel 5 frame, the same
cloned anchor voice, mouth motion from real frames driven by voice RMS,
opaque lower thirds, Ken Burns credited photos, hard cuts, and a padded
ending that is not chopped off.

**Keep this repository private.** The anchor frames and the voice prompt /
reference wavs come from SpongeBob news-anchor clips. See `NOTICE`.

ElevenLabs is intentionally omitted. The only voice path is the one that
was tuned here: F5-TTS prompted with the anchor line, then Seed-VC, then
`finalize.py`.

## What you need

- A Linux machine. A Ryzen 5 / 16 GB RAM laptop with **no NVIDIA GPU** is
  enough, but the voice step is slow on CPU.
- Python 3.10+ (3.11–3.13 are fine) and `ffmpeg` / `ffprobe`.
- Disk space for model weights (several GB in the Hugging Face cache).

Timing on the original CPU box:

- F5-TTS: about **one minute per sentence**.
- Seed-VC: much slower. A ~2-minute clip took many hours. Plan overnight
  for a full show. A two-sentence smoke test can still take a long time.

## Install

```bash
git clone git@github.com:mamesjoore/fish-anchor-news.git
cd fish-anchor-news
./setup.sh
```

`setup.sh` installs ffmpeg if needed, creates `.venv`, installs
`f5-tts==1.1.22` and CPU PyTorch, clones
[Seed-VC](https://github.com/Plachtaa/seed-vc) at
`51383efd921027683c89e5348211d93ff12ac2a8`, applies
`patches/seed-vc-soundfile.patch`, and downloads model weights into the
Hugging Face cache. Weights are not committed.

To reuse installs you already have (skips clones and most downloads):

```bash
export FISH_PYTHON=/path/to/python-with-f5-tts
export SEEDVC_DIR=/path/to/seed-vc   # commit 51383ef, patch applied
export SEEDVC_PYTHON=/path/to/python-that-runs-seed-vc
export HF_HOME=/path/to/huggingface-cache
./setup.sh
```

## Make a clip

```bash
# photos/ must contain every still named in the clip file, already credited
./make_clip.sh path/to/clip.yaml --photos photos/ --out out/my-clip.mp4
```

Same thing as:

```bash
python make_clip.py --clip path/to/clip.yaml --photos photos/ --out out/my-clip.mp4
```

That chain is:

1. F5-TTS, model `F5TTS_v1_Base`, prompt **P3** (`assets/f5/P3.wav` and
   the P3 line in `assets/f5/texts.json`), sentence by sentence, seed
   **11**, `nfe_step=32`, `cfg_strength=2.0`, `sway_sampling_coef=-1`,
   `speed=1.0`, `remove_silence=False`, duration
   `ref_length + syllables/4.9 + commas*0.25 + 0.2`.
2. Assemble takes, trim, pause, word-align.
3. Seed-VC, from the repo root of the clone:

   ```bash
   python inference.py --source <f5.wav> --target assets/voice/vc_ref.wav \
     --output <work>/vo/vc --diffusion-steps 25 --length-adjust 1.0 \
     --inference-cfg-rate 0.7
   ```

4. `finalize.py` copies the converted wav and scales timestamps. It does
   not time-stretch the audio.
5. Render 1080×1920 at 30 fps: RMS mouth states on the three Channel 5
   frames, Ken Burns photos, lower thirds, hard cuts at mid-pause, then
   one second of closed mouth after the last aligned word.
6. Contact sheet and duration file under the work directory.

Each run gets its own `--work` folder (default `work/<clip-name>/`) so
parallel builds do not collide.

Smoke test (still slow, because it uses the real voice path):

```bash
./make_clip.sh tests/short_clip.yaml --photos tests --out out/smoke.mp4
```

### Worked example

`examples/us-2026-11-15/` is the Sunday, November 15, 2026 US-news clip
(`script.md`, `SOURCES.md`, `clip.yaml`, `pauses.json`). Photos are not
in the repo; download them from the Wikimedia URLs in `SOURCES.md` into
a `photos/` folder, then:

```bash
./make_clip.sh examples/us-2026-11-15/clip.yaml \
  --photos /path/to/photos --out out/fishnews-us-2026-11-15.mp4
```

`cfg_us.json` is a historical snapshot of the old generator config and
still contains old `/workspace` paths; do not use it as input.

## Script style

Write a straight SpongeBob news-anchor read.

- Small dry quips only. No corny jokes. Never use "youse".
- No jokes about victims. Use alleged / police-said framing.
- Intro hook, transitions, sign-off.
- The fish appears only on the hook, the transitions, and the sign-off.
  Real credited photos fill most of the runtime.
- Hard cuts. One second of closed mouth after the last word. Never chop
  the ending.

## Research and photos

- Prefer Wikimedia, official portraits, and other clearly licensed stills.
- Keep a `SOURCES.md` with the file name, on-screen credit, source URL,
  and license, the way the November 15 example does.
- Every photo shot in `clip.yaml` needs an on-screen `credit`.
- Do not invent facts. If a source says "police said" or "allegedly",
  keep that wording.

## QA

Open `work/<clip>/build/contact-sheet.jpg` and `durations.txt`.

- Duration matches the planned length, including the one-second hold.
- The last second is a closed mouth. The ending is not cut off.
- Lower thirds are opaque and sit on every shot.
- Photo credits are readable and match `SOURCES.md`.
- The fish appears only on hook / transitions / sign-off.
- The voice is the cloned anchor, not a generic TTS voice.

## Extra formats

`extras/chicagomaxxing-v2` and `extras/fishfiles` are snapshots of other
formats (code and brand assets only). They are not wired into
`make_clip.py` and still have some old hardcoded paths.

## Layout

```
make_clip.sh / make_clip.py   entry point
setup.sh                      install
fish_anchor/                  F5, assemble, finalize, build, lower thirds
assets/                       frames, voice refs, fonts, badge
examples/us-2026-11-15/       worked script + sources
tests/                        two-sentence smoke test
patches/seed-vc-soundfile.patch
AGENTS.md                     instructions for Codex
```
