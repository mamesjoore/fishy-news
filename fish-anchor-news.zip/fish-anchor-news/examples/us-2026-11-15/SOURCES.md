# Photo sources actually used

All photos are cropped and animated with a slow push. Credits appear above the lower third.

## airport.jpg

On-screen credit: Olga Ernst / Wikimedia Commons

Source: https://commons.wikimedia.org/wiki/File:Air_traffic_control_tower,_Orlando_International_Airport.jpg

License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0

## jensen_huang.jpg

On-screen credit: Nvidia / Wikimedia Commons

Source: https://commons.wikimedia.org/wiki/File:Jen-Hsun_Huang_Headshot_(15313247387).jpg

License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0

## new_orleans.jpg

On-screen credit: Yair Haklai / Wikimedia Commons

Source: https://commons.wikimedia.org/wiki/File:Mississippi_River_at_New_Orleans.jpg

License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0

## nvidia_hq.jpg

On-screen credit: Coolcaesar / Wikimedia Commons

Source: https://commons.wikimedia.org/wiki/File:NVIDIA_Headquarters.jpg

License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0

## bessent.jpg

On-screen credit: U.S. Department of the Treasury

Source: https://commons.wikimedia.org/wiki/File:Official_portrait_of_Treasury_Secretary_Scott_Bessent.jpg

License: Public domain 

## duffy.jpg

On-screen credit: U.S. Department of Transportation

Source: https://commons.wikimedia.org/wiki/File:Secretary_of_Transportation_Sean_Duffy_Official_Portrait.jpg

License: Public domain 

## starbase.jpg

On-screen credit: NOAA

Source: https://commons.wikimedia.org/wiki/File:SpaceX_Starbase_Launch_Site_Early_2026.jpg

License: Public domain 

## starship.jpg

On-screen credit: Steve Jurvetson / Wikimedia Commons

Source: https://commons.wikimedia.org/wiki/File:Starship_5_Booster_Landing_on_Mechzilla.jpg

License: CC BY 2.0 https://creativecommons.org/licenses/by/2.0

File photo of the Texas tower / arms catching the Flight 5 booster, not the Saturday orbital-ship catch. Persistent lower third: PRIOR FLIGHT 5 BOOSTER CATCH / FILE IMAGE · NOT SATURDAY’S STARSHIP CATCH. Commons derivative metadata also lists Bech and Prospectprospekt.
