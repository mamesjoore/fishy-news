# Channel 5 — Sunday, November 15, 2026

## Spoken script (20 sentences)

**s00** Good evening; Jensen Huang is considering a return to Nvidia, the Financial Times reports Sunday.

**s01** He resigned Thursday, after revelations about his relationship with Alice Huang; Colette Kress is interim chief executive and remains chief financial officer.

**s02** Treasury Secretary Scott Bessent wants a dramatic shakeup, and an outside successor.

**s03** U.S. intelligence officials suspect Alice Huang, formerly of Megaspeed, of spying for China; Megaspeed says she left in August two thousand twenty-five.

**s04** Nvidia has refuted allegations that Megaspeed diverted its chips to China in violation of export controls.

**s05** Elon Musk signed an open letter demanding Huang return while an independent investigation establishes the facts.

**s06** By Friday's close, Nvidia had lost more than twelve percent for the week, roughly five hundred seventy-three billion dollars in market value.

**s07** In aviation, the weekend has been less than restful.

**s08** Transportation Secretary Sean Duffy declined to apologize for Friday's nationwide ground stop, blaming thirty years of underinvestment and asking Congress for billions.

**s09** Contractor L3Harris was replacing copper with fiber at a remote site when a router overwhelmed the F.A.A. telecommunications network.

**s10** Cancellations continued through the weekend; Duffy expects normal operations by late Sunday or early Monday.

**s11** In Texas, a more successful arrival.

**s12** On Saturday, SpaceX caught Starship itself for the first time after a twenty-two-hour orbital flight.

**s13** The mechanical arms of its Texas launch tower caught the spacecraft, a step toward a fully reusable rocket.

**s14** In New Orleans, investigators have a preliminary finding.

**s15** The N.T.S.B. said Sunday that the tanker Atlantic Asphalt suffered a steering failure, leaving its rudder stuck before Friday's collision.

**s16** It struck the docked American Heritage on the Mississippi River; the cruise vessel rolled over and sank.

**s17** Thirty-two people were hospitalized, none with critical injuries; Mayor Helena Moreno said all aboard were accounted for.

**s18** The cause of the steering failure remains unclear.

**s19** That is the news for Sunday, November fifteenth, two thousand twenty-six; good night.

## Shot plan

Cuts fall halfway through pauses, using finalized sentence timing.

- s00: fish hook.
- s01: Jensen Huang portrait; s02: Bessent portrait; s03–s06: Nvidia headquarters, slow push.
- s07: fish transition.
- s08: Duffy portrait; s09–s10: Orlando control tower, establishing file image, slow push.
- s11: fish transition.
- s12: NOAA Starbase aerial; s13: prior Flight 5 booster catch, labeled FILE PHOTO / PRIOR BOOSTER CATCH throughout. This is not Saturday’s orbital spacecraft catch.
- s14: fish transition.
- s15–s18: Mississippi River at New Orleans, establishing image, slow pan/push; no collision image implied.
- s19: fish sign-off, followed by one second closed-mouth hold after the final aligned word.

Every frame has a new opaque lower third. Photo shots carry the brand bug and source credit. No endcard.

## Source list

Facts supplied in task; no additional reporting or inferred details.

- [Nvidia transition](https://nvidianews.nvidia.com/news/nvidia-announces-ceo-transition)
- [Reuters / Financial Times comeback report](https://www.investing.com/news/stock-market-news/jensen-huang-discusses-comeback-as-nvidia-ceo-with-allies-ft-reports-5028065)
- [CNBC / Bessent and allegations](https://www.cnbc.com/2026/11/15/bessent-nvidia-ceo-lutnick-megaspeed.html)
- [CNA / letter, denial and weekly stock loss](https://www.channelnewsasia.com/world/us-treasury-chief-nvidia-ai-chips-china-jensen-huang-6553411)
- [The Verge / Megaspeed statement](https://www.theverge.com/tech/1033999/jensen-huang-return-nvidia-megaspeed)
- [NBC / FAA and Starship](https://www.nbcnews.com/news/us-news/weekend-rundown-november-15-rcna609191)
- [Reuters / Starship and New Orleans](https://www.devdiscourse.com/article/international/4007128-reuters-us-domestic-news-summary)
- [AP / preliminary NTSB finding](https://www.phillytrib.com/ap/national/ap-news-summary-at-11-55-a-m-est/article_01e22612-3996-5cda-95f4-6bef5f271cf1.html)
